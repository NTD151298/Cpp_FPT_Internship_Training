#pragma once
#ifdef MY_DEFINE
	#define MY_STRING "Dung define"
#else
	#define MY_STRING "Khong dung define"
#endif // MY_DEFINE

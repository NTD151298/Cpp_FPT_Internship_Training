#include <iostream>
#include "test.h"
#define MY_DEFINE
using namespace std;
void main()
{
	cout << MY_STRING;
}

﻿#include <iostream>
#define ADD (a+b)
#define Sub (a-b)
#define Mul (a*b)
#define Div (a/b)
using namespace std;
int main()
{
	short a, b;
	cout << "Nhap a: "; cin >> a;
	cout << "Nhap b: "; cin >> b;
	cout << "Cong: " << ADD << endl;
	cout << "Tru: " << Sub << endl;
	cout << "Nhan: " << Mul << endl;
	cout << "Chia: " << Div << endl;
}
#include <iostream>
#include "methodRedefine.h"
using namespace std;
int main()
{
	cout << myName;
}
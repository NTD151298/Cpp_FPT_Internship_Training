//#pragma once
#define myName 23;
#define myAge 22;

#pragma once
int myAge;
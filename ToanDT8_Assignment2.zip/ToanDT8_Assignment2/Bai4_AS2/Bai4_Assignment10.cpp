#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	unsigned int N;
	float K;
	cout << "Nhap N: ";
	cin >> N;
	K = log2((float)N);
	if(K == (unsigned int)K)
	{
		cout << N << " co la so 2^K"<<endl;
		cout << "K = " << K;
	}
	else{
		cout << N <<" khong la so 2^K";
	}
}

﻿#include <iostream>
#include <cmath>
#include<string>

using namespace std;





int main()
{
    int n, i, a = 0, b = 0, c = 0, j, arr[1000], arr1[1000];
  cout << "Please enter size of arrays: "; cin >> n;

    for (i = 0; i < n; i++)
    {
        cout << "Enter the " << i + 1 << " array: ";
        cin >> arr[i];
    }
    cout << "\nYour array is: \n";
    for (i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "\n\n";
    for (i = 1; i < n; i++) {
        for (j = i; j > 0; j--) {
            arr[j] 
        }
    }
    
    
    cout << "\n\n";

    cout << a;

    cout << "\n\n";
    
    
    
   
    cout << "\n\n\n";
    return 0;
}


